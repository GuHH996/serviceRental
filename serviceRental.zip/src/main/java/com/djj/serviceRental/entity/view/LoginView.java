package com.djj.serviceRental.entity.view;

import com.djj.serviceRental.entity.model.Role;
import com.djj.serviceRental.entity.model.User;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * @Description
 * @Author djj
 * @Date 2022/5/22
 * @Version 1.0
 */
@Component
@Data
public class LoginView implements Serializable {

    private User user;
    private Role role;
}

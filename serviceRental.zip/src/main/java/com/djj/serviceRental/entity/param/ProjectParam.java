package com.djj.serviceRental.entity.param;

import com.djj.serviceRental.entity.model.Project;
import lombok.Data;
import org.springframework.stereotype.Component;

/**
 * @Description
 * @Author djj
 * @Date 2022/5/27
 * @Version 1.0
 */
@Component
@Data
public class ProjectParam extends Project {

    private String strDate;
}

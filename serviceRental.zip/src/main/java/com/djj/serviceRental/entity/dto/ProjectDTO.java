package com.djj.serviceRental.entity.dto;

import com.djj.serviceRental.entity.model.Project;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.stereotype.Component;

/**
 * @Description
 * @Author djj
 * @Date 2022/5/24
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Component
@Data
public class ProjectDTO extends Project {

    //举办服务商信息
    private String userName;
}

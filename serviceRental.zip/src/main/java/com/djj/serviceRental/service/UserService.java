package com.djj.serviceRental.service;

import com.djj.serviceRental.common.exception.JSONResponse;
import com.djj.serviceRental.entity.model.User;
import com.djj.serviceRental.entity.param.LoginParam;
import com.djj.serviceRental.entity.param.RegisterParam;

import java.util.List;

/**
 * @Description
 * @Author djj
 * @Date 2022/5/21
 * @Version 1.0
 */
public interface UserService {

    List<String> selectAllUserIds();

    JSONResponse login(LoginParam loginParam);

    JSONResponse register(RegisterParam registerParam);

    JSONResponse updateUser(User user);

    List<User> selectAllUser();

    JSONResponse deleteUser(Integer loginUserId, Integer userId);
}

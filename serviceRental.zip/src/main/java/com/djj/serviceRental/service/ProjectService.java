package com.djj.serviceRental.service;

import com.djj.serviceRental.common.exception.JSONResponse;
import com.djj.serviceRental.entity.dto.ProjectBaseDTO;
import com.djj.serviceRental.entity.dto.ProjectDTO;
import com.djj.serviceRental.entity.model.Project;
import com.djj.serviceRental.entity.param.ProjectParam;

import java.util.List;

/**
 * @Description
 * @Author djj
 * @Date 2022/5/20
 * @Version 1.0
 */
public interface ProjectService {

    List<String> queryAllTypes();

    List<ProjectBaseDTO> queryProjectsByType(String type);

    ProjectDTO queryProjectInfo(Integer projectId);

    JSONResponse insertProject(ProjectParam projectParam, Integer userId);

    List<ProjectBaseDTO> searchProject(String str);

    List<Project> selectAllProjects();

    JSONResponse deleteProject(Integer proId);

    JSONResponse updateProject(Project project);
}

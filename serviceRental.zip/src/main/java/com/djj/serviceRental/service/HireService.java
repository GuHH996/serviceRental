package com.djj.serviceRental.service;

import com.djj.serviceRental.common.exception.JSONResponse;
import com.djj.serviceRental.entity.dto.HireDTO;
import com.djj.serviceRental.entity.model.Hire;

import java.util.List;

/**
 * @Description
 * @Author djj
 * @Date 2022/5/29
 * @Version 1.0
 */
public interface HireService {

    JSONResponse insertHire(Hire hire,Integer type);

    List<HireDTO> queryUserHire(Integer userId, Integer type);

    JSONResponse deleteHire(Integer hireId, Integer type);
}
